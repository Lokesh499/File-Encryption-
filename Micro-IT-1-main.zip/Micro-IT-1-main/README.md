File Encryption Tool
